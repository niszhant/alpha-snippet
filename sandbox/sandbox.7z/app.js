console.log('before require');
const greet = require('./greet')
greet();


// var a = 1;
// var b = 2;
// var c = a + b;

// console.log(c);

// function greet() {
//     console.log('This is Nishant.');
// }
// greet();

// // functions are first class
// function invokeGreet(fn) {
//     fn();
// }
// invokeGreet(greet);

// // function - expression
// const namaste = function() {
//     console.log('Namaste');
// }
// invokeGreet(namaste);