const greet = function() {
    console.log('Inside greet module. Hello !!!');
}
module.exports =  greet;