let name = 'John Cena';

(function () {
    const name = 'Nishant Kumar';
    console.log('IIFE ' + name);
}());

(function (age) {
    console.log('The age of ' + name + ' is : ' + age);
}(25));

console.log('Outside IIFE ' + name);
